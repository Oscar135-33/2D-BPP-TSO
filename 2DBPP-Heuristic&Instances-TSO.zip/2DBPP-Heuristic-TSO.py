# Heuristic coded by:
# Oscar Garza Hinojosa
# Derek Alejandro Sauceda Morales
# Guillermo Vladimir Flores Báez
# Fernando Yahir García Dávila

import os 
import math
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import time

# These will be dynamically set from the file
BIN_WIDTH = 0
BIN_HEIGHT = 0

def read_objects(filename):
    """
    Reads the object list and bin dimensions from the file.
    Returns: bin_width, bin_height, and the list of objects.
    """
    objects = []
    bin_width = 0
    bin_height = 0

    with open(filename, "r") as f:
        lines = f.readlines()

        # Read number of objects (first line)
        m_line = lines[0].strip()
        try:
            m = int(m_line.split()[0])
        except ValueError:
            raise ValueError(f"Invalid number of objects line: '{m_line}'")

        # Read bin dimensions (second line)
        dim_line = lines[1].strip()
        try:
            bin_width, bin_height = map(int, dim_line.split())
        except ValueError:
            raise ValueError(f"Invalid bin dimensions line: '{dim_line}'")

        # Parse objects from remaining lines (skipping header line 3)
        for line in lines[3:]:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 3:
                continue
            obj_id = parts[0].strip()
            w = int(parts[1].strip())
            h = int(parts[2].strip())
            area = w * h
            objects.append({"id": obj_id, "w": w, "h": h, "area": area})

        if len(objects) != m:
            print(f"⚠️ Warning: Declared number of objects ({m}) does not match actual count ({len(objects)}).")

    return bin_width, bin_height, objects

def check_overlap(rect, new_rect):
    """
    Ensures that two objects do not overlap
    """
    if (new_rect["x"] >= rect["x"] + rect["w"] or
            rect["x"] >= new_rect["x"] + new_rect["w"] or
            new_rect["y"] >= rect["y"] + rect["h"] or
            rect["y"] >= new_rect["y"] + new_rect["h"]):
        return False
    return True

def can_place(placed, candidate):
    """
    Checks if the current object does not overlap with the objects already inserted
    """
    for rect in placed:
        if check_overlap(rect, candidate):
            return False
    return True

def try_place_object(container, obj):
    """
    Attempts to place the object in the container.
    It is first tested in its original orientation, and if it doesn't fit, it is rotated.
    """
    for rotated in [False, True]:
        w = obj["w"]
        h = obj["h"]
        if rotated:
            if w != h:
                w, h = h, w
            else:
                continue

        for x in range(BIN_WIDTH - w + 1):
            for y in range(BIN_HEIGHT - h + 1):
                candidate = {"id": obj["id"], "x": x, "y": y, "w": w, "h": h, "rotated": rotated}
                if can_place(container, candidate):
                    container.append(candidate)
                    return True
    return False

def bin_packing(objects):
    """
    Constructive bin-packing algorithm
    """
    objects = sorted(objects, key=lambda obj: obj["area"], reverse=True)
    containers = []

    for obj in objects:
        placed = False
        for container in containers:
            if try_place_object(container, obj):
                placed = True
                break
        if not placed:
            new_container = []
            if try_place_object(new_container, obj):
                containers.append(new_container)
            else:
                print(f"Object {obj['id']} does not fit in an empty container.")
    return containers

def area_verification(objects):
    """
    Verifies the theoretical minimum number of containers based on total area
    """
    total_area = sum(obj["area"] for obj in objects)
    container_area = BIN_WIDTH * BIN_HEIGHT
    min_containers = math.ceil(total_area / container_area)
    return total_area, container_area, min_containers

def plot_containers(containers):
    """
    Plots each container and its packed objects
    """
    num_containers = len(containers)
    fig, axes = plt.subplots(1, num_containers, figsize=(5*num_containers, 5))

    if num_containers == 1:
        axes = [axes]

    for idx, container in enumerate(containers):
        ax = axes[idx]
        bin_rect = patches.Rectangle((0, 0), BIN_WIDTH, BIN_HEIGHT, linewidth=2, edgecolor='black', facecolor='none')
        ax.add_patch(bin_rect)
        ax.set_xlim(0, BIN_WIDTH)
        ax.set_ylim(0, BIN_HEIGHT)
        ax.set_title(f"Container {idx+1}")
        ax.set_aspect('equal')
        ax.grid(True, linestyle='--', alpha=0.5)

        colors = ['red', 'green', 'blue', 'cyan', 'magenta', 'yellow', 'orange', 'purple', 'brown', 'pink']
        for i, placement in enumerate(container):
            color = colors[i % len(colors)]
            rect = patches.Rectangle((placement["x"], placement["y"]), placement["w"], placement["h"],
                                     linewidth=1, edgecolor='black', facecolor=color, alpha=0.5)
            ax.add_patch(rect)
            orient = "R" if placement["rotated"] else "O"
            ax.text(placement["x"] + placement["w"]/2, placement["y"] + placement["h"]/2,
                    f"{placement['id']} ({orient})", ha='center', va='center', fontsize=10, color='black')
    plt.tight_layout()
    plt.show()

def main():
    # Directory where the file is located
    os.chdir(r"C:\Users\oscar\OneDrive\Escritorio\tso\BENG\BENG\BENG")

    filename = "BENG01.ins2D"
    if not os.path.exists(filename):
        print(f"The file {filename} does not exist in the current directory.")
        return

    global BIN_WIDTH, BIN_HEIGHT
    BIN_WIDTH, BIN_HEIGHT, objects = read_objects(filename)

    print("Read objects:")
    for obj in objects:
        print(f"{obj['id']}: {obj['w']}x{obj['h']} - Area: {obj['area']}")

    total_area, container_area, min_containers = area_verification(objects)
    print("\nTheoretical verification:")
    print(f"Total area of objects: {total_area}")
    print(f"Area of a container: {container_area}")
    print(f"Theoretical minimum number of containers needed: {min_containers}")

    containers = bin_packing(objects)
    best_known_value = min_containers
    gap_percentage = ((len(containers) - best_known_value) / best_known_value) * 100
    print(f"Gap %: {gap_percentage:.2f}%")

    print("\nPacking results:")
    print(f"{len(containers)} containers were used.")
    for i, container in enumerate(containers, start=1):
        print(f"\nContainer {i}:")
        for placement in container:
            orientation = "rotated" if placement["rotated"] else "original"
            print(f"  {placement['id']} at position ({placement['x']},{placement['y']}) with size {placement['w']}x{placement['h']} ({orientation})")

    plot_containers(containers)

if __name__ == "__main__":
    start_time = time.time()
    main()
    end_time = time.time()
    print(f"\nExecution time: {end_time - start_time:.4f} seconds")